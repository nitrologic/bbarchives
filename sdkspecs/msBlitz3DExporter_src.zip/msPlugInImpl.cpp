
/*

  Milkshape3D exporter V1.1

  This baby is Public Domain!

  By Mark Sibly.

  */

#include "stdafx.h"
#include "msPlugInImpl.h"
#include "msLib.h"

#include <math.h>

#include <map>
#include <vector>
#include <string>

using namespace std;

const float PI=3.14159265359f;		//180 degrees
const float TWOPI=PI*2.0f;			//360 degrees
const float HALFPI=PI*.5f;			//90  degrees
const float QUARTERPI=PI*.25f;		//45  degrees

static FILE *file;
static vector<int> chunk_stack;
static vector<int> vertex_bones;
static map<string,int> tex_map;

static float pos0[]={0,0,0};
static float scl1[]={1,1,1};
static float rot0[]={0,0,0};

static void eulerToQuat( const float euler[3],float quat[4] ){
	float r=euler[0];
	float p=euler[1];
	float y=euler[2];
	float sp=sin(p/2),cp=cos(p/2);
	float sy=sin(y/2),cy=cos(y/2);
	float sr=sin(r/2),cr=cos(r/2);
	quat[0]=cr*cp*cy + sr*sp*sy;
	quat[1]=sr*cp*cy - cr*sp*sy;
	quat[2]=cr*sp*cy + sr*cp*sy;
	quat[3]=cr*cp*sy - sr*sp*cy;

	quat[3]=-quat[3];
}

static void mulQuats( const float a[4],const float b[4],float c[4] ){
	c[0]=a[0]*b[0] - a[1]*b[1] - a[2]*b[2] - a[3]*b[3];
	c[1]=a[0]*b[1] + a[1]*b[0] + a[2]*b[3] - a[3]*b[2];
	c[2]=a[0]*b[2] - a[1]*b[3] + a[2]*b[0] + a[3]*b[1];
	c[3]=a[0]*b[3] + a[1]*b[2] - a[2]*b[1] + a[3]*b[0];
}

static void quatToMat( const float q[4],float mat[9] ){
	float xx=q[1]*q[1],yy=q[2]*q[2],zz=q[3]*q[3];
	float xy=q[1]*q[2],xz=q[1]*q[3],yz=q[2]*q[3];
	float wx=q[0]*q[1],wy=q[0]*q[2],wz=q[0]*q[3];

	mat[0]=1-2*(yy+zz);mat[1]=  2*(xy-wz);mat[2]=  2*(xz+wy);
	mat[3]=  2*(xy+wz);mat[4]=1-2*(xx+zz);mat[5]=  2*(yz-wx);
	mat[6]=  2*(xz-wy);mat[7]=  2*(yz+wx);mat[8]=1-2*(xx+yy);
}

static void matMulVec( const float m[9],const float v[3],float t[3] ){
	t[0]=m[0] * v[0] + m[3] * v[1] + m[6] * v[2];
	t[1]=m[1] * v[0] + m[4] * v[1] + m[7] * v[2];
	t[2]=m[2] * v[0] + m[5] * v[1] + m[8] * v[2];
}

static int swap_endian( int n ){
	return ((n&0xff)<<24)|((n&0xff00)<<8)|((n&0xff0000)>>8)|((n&0xff000000)>>24);
}

static void write( const void *buf,int sz ){
	fwrite( buf,sz,1,file );
}

static void writeByte( char c ){
	write( &c,1 );
}

static void writeInt( int n ){
	write( &n,4 );
}

static void writeIntArray( int t[],int n ){
	for( int k=0;k<n;++k ) writeInt( t[k] );
}

static void writeFloat( float n ){
	write( &n,4 );
}

static void writeFloatArray( const float t[],int n ){
	for( int k=0;k<n;++k ) writeFloat( t[k] );
}

static void writeString( const string &t ){
	for( int k=0;k<t.size() && t[k];++k ) writeByte( t[k] );
	writeByte( 0 );
}

static void writePos( const float pos[3] ){
	float t[]={ pos[0],pos[1],-pos[2] };
	writeFloatArray( t,3 );
}

static void writeScale( const float scl[3] ){
	writeFloatArray( scl,3 );
}

static void writeRot( const float rot[3] ){
	float t[4];
	eulerToQuat( rot,t );
	writeFloatArray( t,4 );
}

static void beginChunk( int tag ){
	writeInt( swap_endian( tag ) );
	writeInt( 0 );
	chunk_stack.push_back( ftell( file ) );
}

static void endChunk(){
	int n=ftell( file );
	fseek( file,chunk_stack.back()-4,SEEK_SET );
	writeInt( n-chunk_stack.back() );
	chunk_stack.pop_back();
	fseek( file,n,SEEK_SET );
}

static void writeMesh( msModel *model ){

	beginChunk( 'MESH' );
	writeInt( -1 );			//entity brush_id

	beginChunk( 'VRTS' );
	writeInt( 0 );			//flags
	writeInt( 1 );			//1 tex coord set
	writeInt( 2 );			//2 tex coord components
	int k;
	for( k=0;k<model->nNumMeshes;++k ){
		msMesh *mesh=model->pMeshes+k;
		for( int j=0;j<mesh->nNumVertices;++j ){
			msVertex *vert=mesh->pVertices+j;
			writePos( vert->Vertex );
			writeFloat( vert->u );
			writeFloat( vert->v );
			vertex_bones.push_back( vert->nBoneIndex );
		}
	}
	endChunk();

	int first_vert=0;
	for( k=0;k<model->nNumMeshes;++k ){
		msMesh *mesh=model->pMeshes+k;
		beginChunk( 'TRIS' );
		writeInt( mesh->nMaterialIndex );
		for( int j=0;j<mesh->nNumTriangles;++j ){
			msTriangle *tri=mesh->pTriangles+j;
			writeInt( first_vert+tri->nVertexIndices[0] );
			writeInt( first_vert+tri->nVertexIndices[2] );
			writeInt( first_vert+tri->nVertexIndices[1] );
		}
		first_vert+=mesh->nNumVertices;
		endChunk();
	}

	endChunk();
}

static void writeKeys( msBone *bone ){
	int k;

	float bone_rot[4];
	eulerToQuat( bone->Rotation,bone_rot );

	float bone_mat[9];
	quatToMat( bone_rot,bone_mat );

	if( bone->nNumPositionKeys ){
		beginChunk( 'KEYS' );
		writeInt( 1 );
		for( k=0;k<bone->nNumPositionKeys;++k ){
			msPositionKey *key=bone->pPositionKeys+k;

			float key_pos[]={
				key->Position[0],
				key->Position[1],
				-key->Position[2]
			};
			float t_pos[3];
			matMulVec( bone_mat,key_pos,t_pos );
			float pos[]={
				t_pos[0]+bone->Position[0],
				t_pos[1]+bone->Position[1],
				t_pos[2]-bone->Position[2]
			};

			writeInt( key->fTime );
			writeFloatArray( pos,3 );
		}
		endChunk();
	}
	if( bone->nNumRotationKeys ){
		beginChunk( 'KEYS' );
		writeInt( 4 );
		for( k=0;k<bone->nNumRotationKeys;++k ){
			msRotationKey *key=bone->pRotationKeys+k;

			float key_rot[4],rot[4];
			eulerToQuat( key->Rotation,key_rot );
			mulQuats( key_rot,bone_rot,rot );

			writeInt( key->fTime );
			writeFloatArray( rot,4 );
		}
		endChunk();
	}
}

static void writeBones( msModel *model,const char *parent ){
	int k;
	for( k=0;k<model->nNumBones;++k ){
		msBone *bone=model->pBones+k;
		if( strcmp( bone->szParentName,parent ) ) continue;

		beginChunk( 'NODE' );
			writeString( bone->szName );
			writePos( bone->Position );
			writeScale( scl1 );
			writeRot( bone->Rotation );
			beginChunk( 'BONE' );
			for( int j=0;j<vertex_bones.size();++j ){
				if( vertex_bones[j]==k ){
					writeInt( j );
					writeFloat( 1 );
				}
			}
			endChunk();
			writeKeys( bone );
			writeBones( model,bone->szName );
		endChunk();
	}
}

static void writeModel( msModel *model ){

	//write TEXS chunk...
	beginChunk( 'TEXS' );
	int k,n_texs=0;
	for( k=0;k<model->nNumMaterials;++k ){
		msMaterial *m=model->pMaterials+k;
		string t=m->szDiffuseTexture;
		if( !t.size() ) continue;
		if( tex_map.find( t )!=tex_map.end() ) continue;

		//write out the texture info
		writeString( t );					//file
		writeInt( 1 );						//flags (rgb)
		writeInt( 2 );						//blend (multiply)
		writeFloatArray( pos0,2 );			//position
		writeFloatArray( scl1,2 );			//scale
		writeFloat( 0 );					//rotation

		tex_map.insert( make_pair( t,n_texs ) );
		++n_texs;
	}
	endChunk();

	//write BRUS chunk...
	beginChunk( 'BRUS' );
	writeInt( 1 );							//one tex per brush
	for( k=0;k<model->nNumMaterials;++k ){
		msMaterial *m=model->pMaterials+k;
		writeString( m->szName );			//name
		writeFloatArray( m->Diffuse,4 );	//color
		writeFloat( 0 );					//shininess
		writeInt( 1 );writeInt( 0 );		//blend/FX
		string t=m->szDiffuseTexture;
		if( t.size() ) writeInt( tex_map.find( t )->second );
		else writeInt( -1 );
	}
	endChunk();

	//write geometry/anim...
	beginChunk( 'NODE' );
		writeString( "ROOT" );
		writePos( model->Position );
		writeScale( scl1 );
		writeRot( model->Rotation );
		writeMesh( model );
		if( model->nTotalFrames ){
			beginChunk( 'ANIM' );
			writeInt( 0 );						//flags
			writeInt( model->nTotalFrames );	//frames
			writeFloat( 0 );					//FPS
			endChunk();
		}
		writeBones( model,"" );
	endChunk();
}

BOOL APIENTRY DllMain( HANDLE hModule,DWORD  ul_reason_for_call,LPVOID lpReserved ){
	return TRUE;
}

cMsPlugIn *CreatePlugIn(){
    return new cPlugIn ();
}

cPlugIn::cPlugIn(){
}

cPlugIn::~cPlugIn(){
}

int cPlugIn::GetType(){
    return cMsPlugIn::eTypeExport;
}

const char *cPlugIn::GetTitle(){
	return "Blitz Basic 3D...";
}

int cPlugIn::Execute( msModel *model ){

	if( !model ) return -1;

	if( !model->nNumMeshes ){
		MessageBox( 0,"Nothing to export...","Blitz3D Exporter",MB_OK|MB_ICONWARNING );
		return 0;
	}

    OPENFILENAME ofn={0};
    char szFile[MS_MAX_PATH];
    char szFileTitle[MS_MAX_PATH];
    char szDefExt[32] = "b3d";
    char szFilter[128] = "Blitz3D Files (*.b3d)\0*.b3d\0All Files (*.*)\0*.*\0\0";
    szFile[0] = '\0';
    szFileTitle[0] = '\0';
    ofn.lStructSize = sizeof (OPENFILENAME);
    ofn.lpstrDefExt = szDefExt;
    ofn.lpstrFilter = szFilter;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = MS_MAX_PATH;
    ofn.lpstrFileTitle = szFileTitle;
    ofn.nMaxFileTitle = MS_MAX_PATH;
    ofn.Flags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
    ofn.lpstrTitle = "Export Blitz3D";
    if( !GetSaveFileName (&ofn) ) return 0;

	file=fopen( szFile,"wb" );
	if( !file ) return -1;

	beginChunk( 'BB3D' );
		writeInt( 1 );				//version
		writeModel( model );
	endChunk();

	fclose( file );

	tex_map.clear();
	chunk_stack.clear();
	vertex_bones.clear();

	MessageBox( 0,"Successfully exported Blitz3D file","Blitz3D Exporter",MB_OK );

    msModel_Destroy( model );

    return 0;
}
