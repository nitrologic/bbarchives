
* This lot should be unzipped into your root Blitz directory - ie: you should end up with the folder 
'msvc_demo' and the files 'demolib.dll' and 'demolib.decls' in the userlibs directory.

* Launch Blitz and try out the new commands, eg:

;---start---;
bank=CreateBank(10)

For k=0 To 9
	PokeByte bank,k,k Xor 255	;pre-invert!
Next

DemoLib_InvertBits bank,0,10

For k=0 To 9
	Print PeekByte( bank,k )
Next

Print DemoLib_ShuffleString$( "Read me if you can!" )
;----end----;

* Checkout the workspace and source code.

* Have fun!

